# C++ 코테 문제팩 (30문제 + 개념 6개)

## 어디에 넣나
클코가 만든 앱의 폴더에 그대로 복사:
- `problems/*.json` → 앱의 `src/problems/` 폴더
- `concepts/*.md`   → 앱의 `src/concepts/` 폴더

앱은 import.meta.glob 등으로 폴더를 자동 스캔하므로, 파일만 넣으면 문제/개념이 자동으로 목록에 뜬다.

## 구성 (토픽당 5문제, stage = 난이도 단계 0~5)
- binary_search (bs_01~05): 제곱근, 랜선 자르기, 나무 자르기, 예산, 수의 등장 횟수
- stack (st_01~05): VPS 괄호, 스택 수열, 쇠막대기, 오큰수, 탑
- queue (qu_01~05): 카드2, 요세푸스, 프린터 큐, 미로 BFS, 숨바꼭질 BFS
- greedy (gr_01~05): 동전0, 회의실 배정, ATM, 잃어버린 괄호, 카드 정렬
- dp (dp_01~05): 1로 만들기, 계단 오르기, 0/1 배낭, RGB거리, LIS
- implementation (im_01~05): 달팽이, 행렬 회전, 지뢰찾기, 더하기 사이클, 체스판

## 검증
모든 solution은 g++ 13 (-O2 -std=c++17)로 컴파일·실행해 출력을 생성했고,
유명 문제는 알려진 정답으로 assert 통과 확인 완료.
각 문제의 examples는 화면 표시용, hiddenTests는 제출 시 채점용.

## 형식 (mode)
전부 stdio 모드(백준/LIG 기출 스타일: cin 입력 / cout 출력).
프로그래머스식 function 모드 문제가 필요하면 Claude에 요청.
